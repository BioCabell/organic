Faltan por copiar las imágenes originales del proyecto.
Crea assets/img/ y coloca allí los archivos referenciados en index.html y las páginas internas.
También revisa si existe assets/persona.png; ese archivo va directamente dentro de assets/.
